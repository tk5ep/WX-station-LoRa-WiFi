#ifndef MQTT_UTILS_H_
#define MQTT_UTILS_H_

#include <Arduino.h>

namespace MQTT_Utils {
    void connect();
    void publish();
}
#endif